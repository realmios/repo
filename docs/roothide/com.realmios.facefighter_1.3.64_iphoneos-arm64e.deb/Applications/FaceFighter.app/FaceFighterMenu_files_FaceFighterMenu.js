// Created by iWeb 3.0.1 local-build-20090715

setTransparentGifURL('Media_transparent.gif');function applyEffects()
{var registry=IWCreateEffectRegistry();registry.registerEffects({stroke_0:new IWEmptyStroke()});registry.applyEffects();}
function hostedOnDM()
{return false;}
function onPageLoad()
{loadMozillaCSS('FaceFighterMenu_files_FaceFighterMenuMoz.css')
fixupAllIEPNGBGs();fixAllIEPNGs('Media_transparent.gif');applyEffects()}
